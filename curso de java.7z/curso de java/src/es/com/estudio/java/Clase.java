package es.com.estudio.java;
/**
Primera clase de java con casting*/
public class Clase
{
/** Variable para numeros*/
int numero;
/**Metodo para la documentacion */
public void MIMETODO(){

System.out.println("hola" + numero);

}

}