package es.com.estudio.java.subclases;
public class SubClase extends SuperClase 
{
	public void metodo1 ()
	{
		System.out.println ("m�todo de instancia en SubClase");
	}

	public static void metodo2 ()
	{
		System.out.println ("m�todo de clase en SubClase");
	}
}
