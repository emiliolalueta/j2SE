package es.com.estudio.java.subclases;
public class SuperClase 
{
	public void metodo1 ()
	{
		System.out.println ("m�todo de instancia en SuperClase");
	}
	public static void metodo2 ()
	{
		System.out.println ("m�todo de clase en SuperClase");		
	}
}
