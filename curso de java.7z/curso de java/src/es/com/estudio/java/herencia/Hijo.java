package es.com.estudio.java.herencia;
public class Hijo extends Padre{
	
	public void metodo()
	{
		System.out.println("METODO() EN EL HIJO");
	}

}
