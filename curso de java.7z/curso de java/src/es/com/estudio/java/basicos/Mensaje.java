package es.com.estudio.java.basicos;
public class Mensaje {

	public static void main(String args[]){
	
		System.out.println("Este es un ejemplo en java");	
	}
}