package es.com.estudio.java;
public class primeraclase
	{	
		public static void main (String args[])
		{

			int numero=20;
		/*
			double d=1.52;
			float f=2.34F;// con f convertimos a float 
			short num1,num2,resultado;
			num1=25000;
			num2=14000;
			resultado=(short)(num1 + num2);
			
			System.out.println(resultado);
			numero =(int)d; //asi convierto la d  a entero
			*/
		//************************************************
			
			char caracter1=(char)88;
			char caracter2='@';
			System.out.println(caracter1);
			System.out.println(caracter1);
			
			String texto="41A";			
			numero=Integer.parseInt(texto);
			
			Integer minumero;
			minumero=Integer.parseInt (texto);
			
			System.out.println("valor de numero:" + numero);
			texto=String.valueOf(numero);
			
			//d=texto;
			double d;
			d=Double.parseDouble(texto);
			
			
			
			
			


		}
	}
